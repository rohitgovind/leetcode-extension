function getLeetCodeData() {
  let title = '';
  let code = '';

  const titleElement =
    document.querySelector('div[data-cy="question-title"]') ||         
    document.querySelector('h3') ||                                     
    document.querySelector('.text-title') ||                            
    document.querySelector('div.text-title-large a');                  

  if (titleElement) {
    title = titleElement.innerText.trim();
  }

  const codeEditor = document.querySelector('.view-lines');
  if (codeEditor) {
    const lines = codeEditor.querySelectorAll('.view-line');
    code = Array.from(lines).map(line => line.innerText).join('\n');
  }

  console.log('Extracted Title:', title);
  console.log('Extracted Code:', code);

  return { title, code };
}

document.getElementById('getHintBtn').addEventListener('click', async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    chrome.scripting.executeScript(
      {
        target: { tabId: tab.id },
        function: getLeetCodeData
      },
      async (injectionResults) => {
        const data = injectionResults[0].result;

        console.log('Extracted Data:', data);

        if (!data.title || !data.code) {
          document.getElementById('hintArea').innerText = 'Could not extract problem or code from LeetCode.';
          return;
        }

        const response = await fetch('https://leetcode-extension-backend-yj4g.onrender.com/getHint', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: 'user123',  
            problem: data.title,
            code: data.code
          })
        });

        if (!response.ok) {
          throw new Error('Backend API Error');
        }

        const result = await response.json();
        console.log('AI Hint:', result);

        document.getElementById('hintArea').innerText = result.hint || 'No hint received.';

      }
    );

  } catch (error) {
    console.error('Error fetching hint:', error);
    document.getElementById('hintArea').innerText = 'Error getting AI hint.';
  }
});
