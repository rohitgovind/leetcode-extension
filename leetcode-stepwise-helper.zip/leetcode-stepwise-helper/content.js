console.log('LeetCode Stepwise Helper content script loaded.');
console.log('Extracted Title:', title);
console.log('Extracted Code:', code);
console.log('Groq API Key:', process.env.GROQ_API_KEY);
